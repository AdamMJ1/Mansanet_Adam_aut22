package com.example.mansanet_adam_aut2_2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity implements RadioGroup.OnCheckedChangeListener, CompoundButton.OnCheckedChangeListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        RadioGroup radioGroup = (RadioGroup) findViewById(R.id.radioGroup);
        radioGroup.setOnCheckedChangeListener(this);
        CompoundButton compoundButton = (CompoundButton) findViewById(R.id.swMuestraForm);
        compoundButton.setOnCheckedChangeListener(this);




    }

    public void marcados1(View vista){
        TextView tv = (TextView) findViewById(R.id.tv1);
        CheckBox cb1 = (CheckBox) findViewById(R.id.checkNinguno);

        if (!cb1.isChecked()){
            tv.setText(" ");
        }
        else{
            tv.setText("1");
        }
    }
    public void marcados2(View vista){
        TextView tv = (TextView) findViewById(R.id.tv2);
        CheckBox cb1 = (CheckBox) findViewById(R.id.checkOtro);

        if (!cb1.isChecked()){
            tv.setText(" ");
        }
        else{
            tv.setText("2");
        }
    }
    public void marcados3(View vista){
        TextView tv = (TextView) findViewById(R.id.tv3);
        CheckBox cb1 = (CheckBox) findViewById(R.id.checkTodos);

        if (!cb1.isChecked()){
            tv.setText(" ");
        }
        else {
            tv.setText("3");
        }
    }
    public void marcados4(View vista){
        TextView tv = (TextView) findViewById(R.id.tv4);
        CheckBox cb1 = (CheckBox) findViewById(R.id.checkEstudiando);

        if (!cb1.isChecked()){
            tv.setText(" ");
        }
        else{
            tv.setText("4");
        }
    }

    public void offOn(View vista){
        ToggleButton tb = (ToggleButton) findViewById(R.id.onOffBoton);
        TextView offO = (TextView)  findViewById(R.id.textView5);

        if (tb.isChecked()) {
            offO.setText("Activado");
        }
        else{
            offO.setText("Desactivado");
        }
    }

    @Override
    public void onCheckedChanged(RadioGroup radioGroup, int i) {
        TextView textView = (TextView) findViewById(R.id.elegidoOpcion);
        switch(i){
            case(R.id.xC3):textView.setText("Has elegido la opción: Xenoblade Chronicles 3");break;
            case(R.id.ERing):textView.setText("Has elegido la opción: Elden Ring");break;
            case(R.id.gOW):textView.setText("Has elegido la opción: God of War: Ragnarok");break;
            case(R.id.hFW):textView.setText("Has elegido la opción: Horizon Forbidden West");break;

        }
    }

    @Override
    public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
        TextView mejorJuego = (TextView) findViewById(R.id.mejorJuego);
        RadioButton goW = (RadioButton) findViewById(R.id.gOW);
        RadioButton eR = (RadioButton) findViewById(R.id.ERing);
        RadioButton hfW = (RadioButton) findViewById(R.id.hFW);
        RadioButton xC3 = (RadioButton) findViewById(R.id.xC3);
        CheckBox check1 = (CheckBox)  findViewById(R.id.checkNinguno);
        CheckBox check2 = (CheckBox)  findViewById(R.id.checkOtro);
        CheckBox check3 = (CheckBox)  findViewById(R.id.checkTodos);
        CheckBox check4 = (CheckBox)  findViewById(R.id.checkEstudiando);
        TextView hasElegido = (TextView) findViewById(R.id.elegidoOpcion);
        TextView otrasOpi = (TextView) findViewById(R.id.otrasOpiniones);

        TextView tv1 = (TextView)  findViewById(R.id.tv1);
        TextView tv2 = (TextView)  findViewById(R.id.tv2);
        TextView tv3 = (TextView)  findViewById(R.id.tv3);
        TextView tv4 = (TextView)  findViewById(R.id.tv4);



        if (b){
            mejorJuego.setVisibility(View.VISIBLE);
            goW.setVisibility(View.VISIBLE);
            eR.setVisibility(View.VISIBLE);
            hfW.setVisibility(View.VISIBLE);
            xC3.setVisibility(View.VISIBLE);

            hasElegido.setVisibility(View.VISIBLE);
            otrasOpi.setVisibility(View.VISIBLE);
            check1.setVisibility(View.VISIBLE);
            check2.setVisibility(View.VISIBLE);
            check3.setVisibility(View.VISIBLE);
            check4.setVisibility(View.VISIBLE);

            tv1.setVisibility(View.VISIBLE);
            tv2.setVisibility(View.VISIBLE);
            tv3.setVisibility(View.VISIBLE);
            tv4.setVisibility(View.VISIBLE);

        }
        else{
            mejorJuego.setVisibility(View.INVISIBLE);
            goW.setVisibility(View.INVISIBLE);
            eR.setVisibility(View.INVISIBLE);
            hfW.setVisibility(View.INVISIBLE);
            xC3.setVisibility(View.INVISIBLE);

            hasElegido.setVisibility(View.INVISIBLE);
            otrasOpi.setVisibility(View.INVISIBLE);
            check1.setVisibility(View.INVISIBLE);
            check2.setVisibility(View.INVISIBLE);
            check3.setVisibility(View.INVISIBLE);
            check4.setVisibility(View.INVISIBLE);

            tv1.setVisibility(View.INVISIBLE);
            tv2.setVisibility(View.INVISIBLE);
            tv3.setVisibility(View.INVISIBLE);
            tv4.setVisibility(View.INVISIBLE);

        }

    }

}